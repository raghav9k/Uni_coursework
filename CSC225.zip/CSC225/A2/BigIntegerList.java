import java.util.*;
import java.io.*;
/* This class is for creating a singly linked class of big integer nodes. */
/* Hand this in together with your LinkedList.java. */
class BigIntegerList
{
   int n; // Number of items in the list.
   BigIntegerNode start;
   BigIntegerNode rear;

// You can set debug=true when you are debugging and want
// to print out what your program is doing.
// Please leave your debugging messages in your code when
// you submit it. Change debug back to false before
// submitting your code.
   static final boolean debug= false;

   public BigIntegerList()
   {
       n=0;
       start= null;
       rear= null;
   }
   public static BigIntegerList readBigIntegerList(Scanner in)
   {
       BigIntegerList problem;

       // Insert your code for Question 2 here.

       return(null); 
   }
   public void printBigIntegerList()
   {
       // Insert your code for Question 3 here.
   }
   public void quickSort(int level)
   {
       // Insert your code for Question 4 here.
   }
}
