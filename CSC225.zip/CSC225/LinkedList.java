import java.util.*;
import java.io.*;
import java.nio.file.Paths;
public class LinkedList
{
   int n;
   ListNode start;
   ListNode rear;
    
    public static void main (String[]args){
        //URL path = LinkedList.class.getResource("itest.txt");
        File file = new File("/Users/raghavkhurana/Documents/itest.txt");
        System.out.println(file.getAbsolutePath());
        //Scanner in = new Scanner(file);
       /*try {
            System.out.println(file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        /*System.out.println(System.getProperty("user.dir"));
        Scanner in = new Scanner(Paths.get("itest.txt"));
        LinkedList y = readBigInteger(in);
        
        int count = y.n;
            
        System.out.println(count);*/
        
    }

   public LinkedList()
   {
       n= 0;
       start= null;
       rear= null;
   }
   public LinkedList(int size, ListNode first, ListNode last)
   {
       n= size;
       start= first;
       rear= last;
   }

   public static LinkedList readBigInteger(Scanner in)
   {
       LinkedList x;
       x= new LinkedList();
       
           int counter = readInteger(in);
           int n = counter;
           if(counter==1){
               x.start.data = readInteger(in);
               x.start.next = null;
               x.start=x.rear;
           }
           for(int i = counter;i<=0;i--){
               
           }
       

       // Question 1 code goes here.

       // You can move this statement.

       return(x);
   }
   public void printBigInteger()
   {
       // Question 2 code goes here.
   }
   public void reverse(int level)
   {
       Test.checkList(this); // Do not remove or move this statement.

       // Question 3 code goes here.
   }
   public void plus_plus()
   {
       // Question 4 code goes here.
   }
   public LinkedList plus(LinkedList y)
   {
       LinkedList z;

       z= new LinkedList();

       // Question 5 code goes here.

       return(z);
   }

// You can use these routines for this assignment:

// Tries to read in a non-negative integer from the input stream.
// If it succeeds, the integer read in is returned. 
// Otherwise the method returns -1.
   public static int readInteger(Scanner in)
   {
       int n;

       try{
           n= in.nextInt();
           if (n >=0) return(n);
           else return(-1);
       }
       catch(Exception e)
       {
//        We are assuming legal integer input values are >= zero.
          return(-1);
       }
   }

// Use this for debugging only.

   public void printList()
   {
       ListNode current;

       int count=0;

       current= start;

       while (current != null)
       {
           count++;
           
           System.out.println("Item " + count + " in the list is " 
                            + current.data);
           current= current.next;
       }
   }
}
